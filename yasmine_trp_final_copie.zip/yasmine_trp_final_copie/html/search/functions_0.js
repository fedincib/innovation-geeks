var searchData=
[
  ['affiche_5fenigme',['affiche_enigme',['../enigme2__copie_8h.html#a40e2b1a58c6a4c936bf5d23f3c37142b',1,'affiche_enigme(SDL_Surface *ecran, enigme e):&#160;fonction_save2_copie.c'],['../fonction__save2__copie_8c.html#a40e2b1a58c6a4c936bf5d23f3c37142b',1,'affiche_enigme(SDL_Surface *ecran, enigme e):&#160;fonction_save2_copie.c']]]
];
