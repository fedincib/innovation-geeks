var searchData=
[
  ['resolution',['resolution',['../enigme2__copie_8h.html#a9674933ae81e0a176149183d2f021ae4',1,'resolution(enigme *e, SDL_Surface *ecran):&#160;fonction_save2_copie.c'],['../fonction__save2__copie_8c.html#a9674933ae81e0a176149183d2f021ae4',1,'resolution(enigme *e, SDL_Surface *ecran):&#160;fonction_save2_copie.c']]]
];
