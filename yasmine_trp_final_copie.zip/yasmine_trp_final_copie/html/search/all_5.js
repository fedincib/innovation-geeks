var searchData=
[
  ['im',['im',['../structenigme.html#aa8e0c5257d5e596d933daa1b449f6888',1,'enigme']]],
  ['init_5fenigme',['init_enigme',['../enigme2__copie_8h.html#a7920f8852b09792d93095cc28a4ad919',1,'init_enigme(SDL_Surface *ecran):&#160;fonction_save2_copie.c'],['../fonction__save2__copie_8c.html#a7920f8852b09792d93095cc28a4ad919',1,'init_enigme(SDL_Surface *ecran):&#160;fonction_save2_copie.c']]]
];
